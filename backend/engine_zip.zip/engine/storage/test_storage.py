from engine.scanner.scanner import RepositoryScanner
from engine.parser.parser import parse_file
from engine.metadata.extractor import MetadataExtractor
from engine.chunker.generator import ChunkGenerator
from engine.embeddings.embedder import Embedder
from engine.storage.storage import Storage


scanner = RepositoryScanner("../")

files = scanner.scan()

embedder = Embedder()

all_chunks = []


for file in files:

    tree = parse_file(file)

    extractor = MetadataExtractor(file.content)

    extractor.traverse(tree.root_node)

    generator = ChunkGenerator(file, extractor)

    chunks = generator.generate()

    for chunk in chunks:

        chunk.embedding = embedder.create_embedding(
            chunk.content
        )

        all_chunks.append(chunk)


storage = Storage()

storage.save_chunks(

    all_chunks,

    "repository.json"

)

print("Repository saved successfully!")