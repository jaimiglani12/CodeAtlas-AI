import json

from engine.storage.database import Database


class Storage:

    def __init__(self):

        self.db = Database()

    def save_chunks(self, chunks, filename):

        data = []

        for chunk in chunks:

            data.append({

                "name": chunk.name,

                "type": chunk.chunk_type,

                "file": chunk.file_path,

                "language": chunk.language,

                "content": chunk.content,

                "start_line": chunk.start_line,

                "end_line": chunk.end_line,

                "embedding": (

                    chunk.embedding.tolist()

                    if chunk.embedding is not None

                    else None

                )

            })

        with open(filename, "w") as file:

            json.dump(

                data,

                file,

                indent=4

            )