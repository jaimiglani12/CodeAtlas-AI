import psycopg2


class Database:

    def __init__(self):

        self.connection = psycopg2.connect(

            host="localhost",

            port=5432,

            database="codeatlas",

            user="postgres",

            password="your_password"

        )

        self.cursor = self.connection.cursor()