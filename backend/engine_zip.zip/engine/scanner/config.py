# Supported source code files

EXTENSION_TO_LANGUAGE = {

    ".py": "python",

    ".js": "javascript",

    ".ts": "typescript",

    ".java": "java",

    ".cpp": "cpp",

    ".c": "c",

    ".go": "go",

    ".rs": "rust"

}


# Ignore these folders

IGNORE_FOLDERS = [

    ".git",

    "__pycache__",

    "node_modules",

    "venv",

    ".venv",

    "build",

    "dist"

]