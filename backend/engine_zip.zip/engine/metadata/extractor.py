from engine.models.metadata import (
    FunctionInfo,
    ClassInfo,
    ImportInfo,
)


class MetadataExtractor:

    def __init__(self, index):

        self.index = index

        self.current_file = None
        self.current_function = None
        self.source_code = ""

    def extract(self, file, tree):

        self.current_file = file
        self.source_code = file.content

        self.traverse(tree.root_node)

    def traverse(self, node):

        # =====================================
        # Function Definition
        # =====================================

        if node.type == "function_definition":

            name_node = node.child_by_field_name("name")

            if name_node:

                name = self.source_code[
                    name_node.start_byte:name_node.end_byte
                ]

                function = FunctionInfo(

                    name=name,

                    file_path=self.current_file.path,

                    start_line=node.start_point[0] + 1,

                    end_line=node.end_point[0] + 1,

                    start_byte=node.start_byte,

                    end_byte=node.end_byte

                )

                self.index.add_function(function)

                previous_function = self.current_function

                self.current_function = name

                for child in node.children:

                    self.traverse(child)

                self.current_function = previous_function

                return

        # =====================================
        # Class Definition
        # =====================================

        if node.type == "class_definition":

            name_node = node.child_by_field_name("name")

            if name_node:

                name = self.source_code[
                    name_node.start_byte:name_node.end_byte
                ]

                cls = ClassInfo(

                    name=name,

                    file_path=self.current_file.path,

                    start_line=node.start_point[0] + 1,

                    end_line=node.end_point[0] + 1,

                    start_byte=node.start_byte,

                    end_byte=node.end_byte

                )

                self.index.add_class(cls)

        # =====================================
        # Import Statement
        # =====================================

        elif node.type == "import_statement":

            statement = self.source_code[
                node.start_byte:node.end_byte
            ]

            imp = ImportInfo(

                file_path=self.current_file.path,

                statement=statement

            )

            self.index.add_import(imp)

        # =====================================
        # Function Call
        # =====================================

        elif node.type == "call":

            function_node = node.child_by_field_name("function")

            if function_node and self.current_function:

                called_function = self.source_code[
                    function_node.start_byte:function_node.end_byte
                ]

                # Handle attribute calls like:
                # self.login()
                # user.authenticate()
                if "." in called_function:
                    called_function = called_function.split(".")[-1]

                self.index.add_call(

                    self.current_function,

                    called_function

                )

        # =====================================
        # DFS
        # =====================================

        for child in node.children:

            self.traverse(child)