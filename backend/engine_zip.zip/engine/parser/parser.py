from tree_sitter import Language, Parser
import tree_sitter_python


PYTHON_LANGUAGE = Language(tree_sitter_python.language())


class CodeParser:

    def __init__(self):

        self.parser = Parser(PYTHON_LANGUAGE)

    def parse(self, file):

        return self.parser.parse(

            file.content.encode("utf-8")

        )