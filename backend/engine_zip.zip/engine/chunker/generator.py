from engine.models.chunk import Chunk


class ChunkGenerator:

    def __init__(self, index):

        self.index = index

    def generate(self):

        # ---------- Function Chunks ----------

        for function in self.index.functions:

            file = self.index.get_file(function.file_path)

            if file is None:
                continue

            code = file.content[
                function.start_byte:function.end_byte
            ]

            content = self.build_function_chunk(
                function,
                file,
                code
            )

            chunk = Chunk(

                chunk_type="function",

                name=function.name,

                file_path=function.file_path,

                language=file.language,

                content=content,

                start_line=function.start_line,

                end_line=function.end_line

            )

            self.index.add_chunk(chunk)

        # ---------- Class Chunks ----------

        for cls in self.index.classes:

            file = self.index.get_file(cls.file_path)

            if file is None:
                continue

            code = file.content[
                cls.start_byte:cls.end_byte
            ]

            content = self.build_class_chunk(
                cls,
                file,
                code
            )

            chunk = Chunk(

                chunk_type="class",

                name=cls.name,

                file_path=cls.file_path,

                language=file.language,

                content=content,

                start_line=cls.start_line,

                end_line=cls.end_line

            )

            self.index.add_chunk(chunk)

    def build_function_chunk(
        self,
        function,
        file,
        code
    ):

        text = ""

        text += f"Function Name: {function.name}\n"

        text += f"File: {function.file_path}\n"

        text += f"Language: {file.language}\n\n"

        text += "Code:\n"

        text += code

        return text

    def build_class_chunk(
        self,
        cls,
        file,
        code
    ):

        text = ""

        text += f"Class Name: {cls.name}\n"

        text += f"File: {cls.file_path}\n"

        text += f"Language: {file.language}\n\n"

        text += "Code:\n"

        text += code

        return text